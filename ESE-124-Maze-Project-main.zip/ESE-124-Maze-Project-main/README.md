# ESE-124-Maze-Project

Member:
Jin Yuan Chen, jin.chen@stonybrook.edu
Tim Li,        chenyi.li@stonybrook.edu
Hao En_Tsai    Hao-En.Tsai@stonybrook.edu

White board:
https://miro.com/app/board/uXjVKSS4Iko=/
