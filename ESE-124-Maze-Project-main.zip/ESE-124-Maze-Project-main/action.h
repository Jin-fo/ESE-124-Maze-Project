

/*void excute() 

*/




int action(char);

extern ant;


