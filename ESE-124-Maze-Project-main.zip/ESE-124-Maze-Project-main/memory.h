ANT peek();

void push(ANT);

void pop();

void clear();